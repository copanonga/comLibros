<?php
defined('_JEXEC') or die;

class LibrosTableLibro extends JTable
{
    
    public function __construct(&$db)
    {
        Funciones::mostrarZona(__CLASS__,__METHOD__,"Constructor",0);
        parent::__construct('#__libros', 'id', $db);
    }

    public function bind($array, $ignore = '')
    {
        Funciones::mostrarZona(__CLASS__,__METHOD__,$array,1);
        return parent::bind($array, $ignore);
    }

    public function store($updateNulls = false)
    {
        Funciones::mostrarZona(__CLASS__,__METHOD__,"Store",1);
        Funciones::mostrarZona(__CLASS__,__METHOD__,$updateNulls,0);
        return parent::store($updateNulls);
    }
    
    public function publish($pks = null, $state = 1, $userId = 0)
    {
        
        $k = $this->_tbl_key;

        JArrayHelper::toInteger($pks);
        $state = (int) $state;

                
        if (empty($pks))
        {
            if ($this->$k)
            {
                $pks = array($this->$k);
            }
            else
            {
                $this->setError(JText::_('JLIB_DATABASE_ERROR_NO_ROWS_SELECTED'));
                return false;
            }
        }

        $where = $k . '=' . implode(' OR ' . $k . '=', $pks);

        $query = $this->_db->getQuery(true)
                ->update($this->_db->quoteName($this->_tbl))
                ->set($this->_db->quoteName('state') . ' = ' . (int) $state)
                ->where($where);
        $this->_db->setQuery($query);

        try
        {
            $this->_db->execute();
        }
        catch (RuntimeException $e)
        {
            $this->setError($e->getMessage());
            return false;
        }

        if (in_array($this->$k, $pks))
        {
            $this->state = $state;
        }

        $this->setError('');

        return true;
    }
        
}