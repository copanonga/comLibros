<?php
defined('_JEXEC') or die;

class LibrosControllerLibro extends JControllerForm
{

}